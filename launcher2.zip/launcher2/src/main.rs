// AppLauncher & Watchdog — pure Win32, x64, works on any GPU/CPU
// No VC++ runtime, no PowerShell, no GPU dependency.
//
// ============================================================
//  USER CONFIG — change these four values, then rebuild
// ============================================================
//
// CPU_AFFINITY_MASK
//   Which logical CPU threads the launched app may use.
//   Bit 0 = Thread 0 (Core 0). Set bit 0 to 0 to skip it,
//   keeping Windows/input handlers on a free core.
//
//   Common values:
//     4-core  / 8-thread  : 0x00FE
//     6-core  / 12-thread : 0x0FFE
//     8-core  / 16-thread : 0xFFFE    <- good default for most gaming PCs
//    12-core  / 24-thread : 0xFFFFFE
//    16-core  / 32-thread : 0xFFFFFFFE
//
//   SAFE: bad values are clamped at startup, never crashes.
//
#![allow(static_mut_refs, non_snake_case)]
const CPU_AFFINITY_MASK: usize = 0xFFFE;

// WATCHDOG_INTERVAL_SECS
//   How often the watchdog checks each process. 1-3600.
const WATCHDOG_INTERVAL_SECS: u64 = 3;

// RAM_LIMIT_MIB
//   Kill the process if working-set RAM exceeds this (MiB). 0 = disabled.
const RAM_LIMIT_MIB: usize = 4096;

// HANG_LIMIT_SECS
//   Kill if the main window stays "Not Responding" this long. 0 = disabled.
//   Console apps (no window) are never flagged as hung.
const HANG_LIMIT_SECS: u64 = 30;

// ============================================================
//  END OF USER CONFIG
// ============================================================

use std::{
    collections::HashMap,
    ffi::OsStr,
    fs,
    mem,
    os::windows::ffi::OsStrExt,
    path::{Path, PathBuf},
    ptr,
    sync::{
        atomic::{AtomicBool, AtomicU32, AtomicUsize, Ordering},
        Arc,
    },
    thread,
    time::{Duration, Instant},
};
use serde::{Deserialize, Serialize};
use windows_sys::Win32::{
    Foundation::*,
    Graphics::Gdi::*,
    Security::*,
    System::{
        Com::CoTaskMemFree,
        Diagnostics::ToolHelp::*,
        LibraryLoader::GetModuleHandleW,
        Diagnostics::Debug::FormatMessageW,
        ProcessStatus::*,
        SystemInformation::{GetSystemInfo, SYSTEM_INFO},
        Threading::*,
    },
    UI::{
        Shell::ShellExecuteW,
        WindowsAndMessaging::*,
    },
};

// ── Manual FFI Links & Structs (Bypassing windows-sys feature gates) ──────────

#[link(name = "comdlg32")]
extern "system" {
    fn GetOpenFileNameW(lpofn: *mut OPENFILENAMEW) -> BOOL;
}

#[link(name = "shell32")]
extern "system" {
    fn SHBrowseForFolderW(lpbi: *mut BROWSEINFOW) -> *mut std::ffi::c_void;
    fn SHGetPathFromIDListW(pidl: *const std::ffi::c_void, pszPath: *mut u16) -> BOOL;
}

#[repr(C)]
#[allow(non_camel_case_types, non_snake_case)]
struct OPENFILENAMEW {
    lStructSize:        u32,
    hwndOwner:          HWND,
    hInstance:          HINSTANCE,
    lpstrFilter:        *const u16,
    lpstrCustomFilter:  *mut u16,
    nMaxCustFilter:     u32,
    nFilterIndex:       u32,
    lpstrFile:          *mut u16,
    nMaxFile:           u32,
    lpstrFileTitle:     *mut u16,
    nMaxFileTitle:      u32,
    lpstrInitialDir:    *const u16,
    lpstrTitle:         *const u16,
    Flags:              u32,
    nFileOffset:        u16,
    nFileExtension:     u16,
    lpstrDefExt:        *const u16,
    lCustData:          LPARAM,
    lpfnHook:           Option<unsafe extern "system" fn(HWND, u32, WPARAM, LPARAM) -> usize>,
    lpTemplateName:     *const u16,
    pvReserved:         *mut std::ffi::c_void,
    dwReserved:         u32,
    FlagsEx:            u32,
}

const OFN_FILEMUSTEXIST: u32  = 0x0001000;
const OFN_PATHMUSTEXIST: u32  = 0x0000800;
const OFN_NOCHANGEDIR:   u32  = 0x0000008;

#[repr(C)]
#[allow(non_camel_case_types, non_snake_case)]
struct BROWSEINFOW {
    hwndOwner:      HWND,
    pidlRoot:       *mut std::ffi::c_void,
    pszDisplayName: *mut u16,
    lpszTitle:      *const u16,
    ulFlags:        u32,
    lpfn:           Option<unsafe extern "system" fn(HWND, u32, LPARAM, LPARAM) -> i32>,
    lParam:         LPARAM,
    iImage:         i32,
}

const BIF_RETURNONLYFSDIRS: u32 = 0x0001;

// FormatMessageW flags
const FORMAT_MESSAGE_FROM_SYSTEM:    u32 = 0x00001000;
const FORMAT_MESSAGE_IGNORE_INSERTS: u32 = 0x00000200;

// ── string helpers ────────────────────────────────────────────────────────────

fn wide(s: &str) -> Vec<u16> {
    OsStr::new(s).encode_wide().chain(Some(0)).collect()
}

fn from_wide_nul(buf: &[u16]) -> String {
    let end = buf.iter().position(|&c| c == 0).unwrap_or(buf.len());
    String::from_utf16_lossy(&buf[..end])
}

// ── last Win32 error ──────────────────────────────────────────────────────────

fn last_err() -> (u32, String) {
    unsafe {
        let code = GetLastError();
        let mut buf = [0u16; 512];
        let n = FormatMessageW(
            FORMAT_MESSAGE_FROM_SYSTEM | FORMAT_MESSAGE_IGNORE_INSERTS,
            ptr::null(),
            code,
            0,
            buf.as_mut_ptr(),
            buf.len() as u32,
            ptr::null_mut(),
        );
        let msg = if n > 0 {
            from_wide_nul(&buf[..n as usize]).trim().to_owned()
        } else {
            format!("unknown error {:#010x}", code)
        };
        (code, msg)
    }
}

fn msgbox(hwnd: HWND, title: &str, text: &str, flags: u32) -> i32 {
    unsafe { MessageBoxW(hwnd, wide(text).as_ptr(), wide(title).as_ptr(), flags) }
}

// ── elevation ─────────────────────────────────────────────────────────────────

fn is_elevated() -> bool {
    unsafe {
        let mut tok: HANDLE = 0;
        if OpenProcessToken(GetCurrentProcess(), TOKEN_QUERY, &mut tok) == 0 {
            return false;
        }
        let mut elev = TOKEN_ELEVATION { TokenIsElevated: 0 };
        let mut ret = 0u32;
        let ok = GetTokenInformation(
            tok,
            TokenElevation,
            &mut elev as *mut _ as *mut _,
            mem::size_of_val(&elev) as u32,
            &mut ret,
        );
        CloseHandle(tok);
        ok != 0 && elev.TokenIsElevated != 0
    }
}

fn elevate_self() -> bool {
    let exe = std::env::current_exe().unwrap_or_default();
    let exe_w = wide(exe.to_str().unwrap_or(""));
    let verb = wide("runas");
    let r = unsafe {
        ShellExecuteW(0, verb.as_ptr(), exe_w.as_ptr(), ptr::null(), ptr::null(), SW_SHOWNORMAL as i32)
    };
    r as usize > 32
}

// ── CPU affinity ──────────────────────────────────────────────────────────────

fn logical_cpu_count() -> usize {
    unsafe {
        let mut si: SYSTEM_INFO = mem::zeroed();
        GetSystemInfo(&mut si);
        si.dwNumberOfProcessors as usize
    }
}

fn safe_mask(requested: usize) -> usize {
    let n = logical_cpu_count().min(mem::size_of::<usize>() * 8);
    let all: usize = if n >= mem::size_of::<usize>() * 8 {
        usize::MAX
    } else {
        (1usize << n) - 1
    };
    let m = requested & all;
    if m == 0 { all & !1 } else { m }   // never 0; fallback = all except thread 0
}

fn apply_affinity(handle: HANDLE, mask: usize) {
    unsafe { SetProcessAffinityMask(handle, mask); }
}

// ── saved entries ─────────────────────────────────────────────────────────────

#[derive(Serialize, Deserialize, Clone, Debug)]
struct Entry {
    path:  String,
    label: String,
}

fn cfg_path() -> PathBuf {
    let mut p = std::env::current_exe().unwrap_or_default();
    p.set_file_name("launcher_entries.json");
    p
}

fn load_entries() -> Vec<Entry> {
    fs::read_to_string(cfg_path())
        .ok()
        .and_then(|s| serde_json::from_str(&s).ok())
        .unwrap_or_default()
}

fn save_entries(v: &[Entry]) {
    if let Ok(j) = serde_json::to_string_pretty(v) {
        let _ = fs::write(cfg_path(), j);
    }
}

// ── process launch ────────────────────────────────────────────────────────────

struct Launched {
    pid:        u32,
    handle:     HANDLE,
    is_script: bool,
}

fn launch_app(path: &Path, mask: usize) -> Result<Launched, String> {
    let ext = path
        .extension()
        .and_then(|e| e.to_str())
        .unwrap_or("")
        .to_lowercase();
    let is_script = matches!(ext.as_str(), "bat" | "cmd");

    let cmdline = if is_script {
        format!("cmd.exe /C \"{}\"", path.display())
    } else {
        format!("\"{}\"", path.display())
    };
    let mut cw: Vec<u16> = OsStr::new(&cmdline).encode_wide().chain(Some(0)).collect();

    let mut si: STARTUPINFOW         = unsafe { mem::zeroed() };
    let mut pi: PROCESS_INFORMATION = unsafe { mem::zeroed() };
    si.cb = mem::size_of::<STARTUPINFOW>() as u32;

    let ok = unsafe {
        CreateProcessW(
            ptr::null(),
            cw.as_mut_ptr(),
            ptr::null(),
            ptr::null(),
            FALSE,
            CREATE_NEW_CONSOLE,
            ptr::null(),
            ptr::null(),
            &si,
            &mut pi,
        )
    };
    if ok == 0 {
        let (code, msg) = last_err();
        return Err(format!("CreateProcess failed ({:#010x}): {}", code, msg));
    }
    unsafe { CloseHandle(pi.hThread); }
    apply_affinity(pi.hProcess, mask);
    Ok(Launched { pid: pi.dwProcessId, handle: pi.hProcess, is_script })
}

// ── process tree (BAT child tracking) ────────────────────────────────────────

fn child_pids(root: u32) -> Vec<u32> {
    let snap = unsafe { CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS, 0) };
    if snap == INVALID_HANDLE_VALUE { return vec![]; }
    let mut entry: PROCESSENTRY32W = unsafe { mem::zeroed() };
    entry.dwSize = mem::size_of::<PROCESSENTRY32W>() as u32;
    let mut parent_of: HashMap<u32, u32> = HashMap::new();
    unsafe {
        if Process32FirstW(snap, &mut entry) != 0 {
            loop {
                parent_of.insert(entry.th32ProcessID, entry.th32ParentProcessID);
                if Process32NextW(snap, &mut entry) == 0 { break; }
            }
        }
        CloseHandle(snap);
    }
    // BFS from root
    let mut out = vec![];
    let mut q   = vec![root];
    while let Some(p) = q.pop() {
        for (&pid, &par) in &parent_of {
            if par == p && pid != p {
                out.push(pid);
                q.push(pid);
            }
        }
    }
    out
}

// ── process checks ────────────────────────────────────────────────────────────

fn pid_alive(pid: u32) -> bool {
    unsafe {
        let h = OpenProcess(PROCESS_QUERY_LIMITED_INFORMATION, FALSE, pid);
        if h == 0 { return false; }
        let mut code = 0u32;
        let ok = GetExitCodeProcess(h, &mut code);
        CloseHandle(h);
        ok != 0 && code == 259u32
    }
}

fn working_set_mib(pid: u32) -> Option<usize> {
    unsafe {
        let h = OpenProcess(PROCESS_QUERY_INFORMATION | PROCESS_VM_READ, FALSE, pid);
        if h == 0 { return None; }
        let mut pmc: PROCESS_MEMORY_COUNTERS = mem::zeroed();
        pmc.cb = mem::size_of_val(&pmc) as u32;
        let ok = GetProcessMemoryInfo(h, &mut pmc, pmc.cb);
        CloseHandle(h);
        if ok != 0 { Some(pmc.WorkingSetSize / (1024 * 1024)) } else { None }
    }
}

fn kill_pid(pid: u32) {
    unsafe {
        let h = OpenProcess(PROCESS_TERMINATE, FALSE, pid);
        if h != 0 {
            TerminateProcess(h, 1);
            CloseHandle(h);
        }
    }
}

static ENUM_TARGET: AtomicU32   = AtomicU32::new(0);
static ENUM_RESULT: AtomicUsize = AtomicUsize::new(0);

unsafe extern "system" fn enum_cb(hwnd: HWND, _: LPARAM) -> BOOL {
    let target = ENUM_TARGET.load(Ordering::Relaxed);
    let mut wnd_pid = 0u32;
    GetWindowThreadProcessId(hwnd, &mut wnd_pid);
    if wnd_pid == target && IsWindowVisible(hwnd) != 0 {
        ENUM_RESULT.store(hwnd as usize, Ordering::Relaxed);
        return FALSE;
    }
    TRUE
}

fn window_for_pid(pid: u32) -> HWND {
    ENUM_TARGET.store(pid, Ordering::Relaxed);
    ENUM_RESULT.store(0,   Ordering::Relaxed);
    unsafe { EnumWindows(Some(enum_cb), 0); }
    ENUM_RESULT.load(Ordering::Relaxed) as HWND
}

fn is_hung(pid: u32) -> bool {
    let hwnd = window_for_pid(pid);
    if hwnd == 0 { return false; }
    unsafe { IsHungAppWindow(hwnd) != 0 }
}

// ── watchdog ──────────────────────────────────────────────────────────────────

#[derive(Clone)]
struct Violation {
    pid:    u32,
    path:   String,
    reason: String,
}

fn watchdog(
    root_pid:  u32,
    root_path: String,
    is_script: bool,
    ram_mib:   usize,
    hang_secs: u64,
    interval:  Duration,
    stop:      Arc<AtomicBool>,
) -> Vec<Violation> {
    let mut violations: Vec<Violation> = vec![];
    let mut hung_since: HashMap<u32, Instant> = HashMap::new();
    let mut known_children: HashMap<u32, String> = HashMap::new();

    loop {
        thread::sleep(interval);
        if stop.load(Ordering::Relaxed) { break; }

        if is_script {
            for c in child_pids(root_pid) {
                known_children.entry(c).or_insert_with(|| {
                    format!("child of PID {} (root: {})", root_pid, root_path)
                });
            }
        }

        if !pid_alive(root_pid) {
            for (&c, _) in &known_children {
                if pid_alive(c) { kill_pid(c); }
            }
            break;
        }

        let mut watch: Vec<(u32, String)> = vec![(root_pid, root_path.clone())];
        for (&c, label) in &known_children {
            if pid_alive(c) {
                watch.push((c, label.clone()));
            }
        }

        for (pid, path) in watch {
            if !pid_alive(pid) { hung_since.remove(&pid); continue; }

            if ram_mib > 0 {
                if let Some(ws) = working_set_mib(pid) {
                    if ws > ram_mib {
                        violations.push(Violation {
                            pid,
                            path: path.clone(),
                            reason: format!("RAM {} MiB > limit {} MiB", ws, ram_mib),
                        });
                        kill_pid(pid);
                        continue;
                    }
                }
            }

            if hang_secs > 0 && is_hung(pid) {
                let since = hung_since.entry(pid).or_insert_with(Instant::now);
                if since.elapsed().as_secs() >= hang_secs {
                    violations.push(Violation {
                        pid,
                        path: path.clone(),
                        reason: format!("Hung for > {} seconds", hang_secs),
                    });
                    kill_pid(pid);
                    hung_since.remove(&pid);
                }
            } else {
                hung_since.remove(&pid);
            }
        }
    }
    violations
}

// ── file / folder pickers ─────────────────────────────────────────────────────

fn pick_file(owner: HWND) -> Option<PathBuf> {
    let mut buf = [0u16; 32768];

    let mut filter: Vec<u16> = vec![];
    for s in &[
        "Executables & Scripts (*.exe;*.bat;*.cmd)\0*.exe;*.bat;*.cmd\0",
        "All files (*.*)\0*.*\0",
        "\0",
    ] {
        filter.extend(OsStr::new(s).encode_wide());
    }

    let title = wide("Select application to add");
    let mut ofn: OPENFILENAMEW = unsafe { mem::zeroed() };
    ofn.lStructSize = mem::size_of::<OPENFILENAMEW>() as u32;
    ofn.hwndOwner   = owner;
    ofn.lpstrFilter = filter.as_ptr();
    ofn.lpstrFile   = buf.as_mut_ptr();
    ofn.nMaxFile    = buf.len() as u32;
    ofn.lpstrTitle  = title.as_ptr();
    ofn.Flags       = OFN_FILEMUSTEXIST | OFN_PATHMUSTEXIST | OFN_NOCHANGEDIR;

    if unsafe { GetOpenFileNameW(&mut ofn) } != 0 {
        Some(PathBuf::from(from_wide_nul(&buf)))
    } else {
        None
    }
}

fn pick_folder(owner: HWND) -> Option<PathBuf> {
    let title = wide("Select folder to scan for .exe / .bat files");
    let mut bi: BROWSEINFOW = unsafe { mem::zeroed() };
    bi.hwndOwner = owner;
    bi.lpszTitle = title.as_ptr();
    bi.ulFlags   = BIF_RETURNONLYFSDIRS;

    let pidl = unsafe { SHBrowseForFolderW(&mut bi) };
    if pidl.is_null() { return None; }

    let mut path = [0u16; 260];
    let ok = unsafe { SHGetPathFromIDListW(pidl as _, path.as_mut_ptr()) };
    unsafe { CoTaskMemFree(pidl as _); }
    if ok != 0 { Some(PathBuf::from(from_wide_nul(&path))) } else { None }
}

fn scan_folder(dir: &Path) -> Vec<PathBuf> {
    fs::read_dir(dir)
        .ok()
        .into_iter()
        .flatten()
        .flatten()
        .map(|e| e.path())
        .filter(|p| {
            p.is_file()
                && matches!(
                    p.extension()
                        .and_then(|e| e.to_str())
                        .unwrap_or("")
                        .to_lowercase()
                        .as_str(),
                    "exe" | "bat" | "cmd"
                )
        })
        .collect()
}

// ── window ────────────────────────────────────────────────────────────────────

const ID_LIST:       usize = 101;
const ID_ADD_FILE:   usize = 102;
const ID_ADD_FOLDER: usize = 103;
const ID_REMOVE:     usize = 104;
const ID_LAUNCH:     usize = 105;
const ID_STATUS:     usize = 106;
const WM_DONE:       u32   = WM_APP + 1;

struct Ui {
    entries:          Vec<Entry>,
    list:             HWND,
    status:           HWND,
    hw_mask:          HWND,
    hw_ivl:           HWND,
    hw_ram:           HWND,
    hw_hang:          HWND,
}

unsafe fn read_edit_hex(h: HWND) -> Option<usize> {
    let mut buf = [0u16; 64];
    let n = GetWindowTextW(h, buf.as_mut_ptr(), buf.len() as i32);
    if n <= 0 { return None; }
    let s = String::from_utf16_lossy(&buf[..n as usize]);
    let s = s.trim().trim_start_matches("0x").trim_start_matches("0X");
    usize::from_str_radix(s, 16).ok()
}

unsafe fn read_edit_u64(h: HWND) -> Option<u64> {
    let mut buf = [0u16; 64];
    let n = GetWindowTextW(h, buf.as_mut_ptr(), buf.len() as i32);
    if n <= 0 { return None; }
    let s = String::from_utf16_lossy(&buf[..n as usize]);
    s.trim().parse::<u64>().ok()
}

static mut UI: Option<Ui> = None;
const ID_SET_MASK: usize = 201;
const ID_SET_IVL:  usize = 202;
const ID_SET_RAM:  usize = 203;
const ID_SET_HANG: usize = 204;

fn rebuild_list(list: HWND, entries: &[Entry]) {
    unsafe {
        SendMessageW(list, LB_RESETCONTENT, 0, 0);
        for e in entries {
            let w = wide(&e.label);
            SendMessageW(list, LB_ADDSTRING, 0, w.as_ptr() as LPARAM);
        }
    }
}

fn set_status(hwnd: HWND, s: &str) {
    unsafe { SetWindowTextW(hwnd, wide(s).as_ptr()); }
}

#[allow(static_mut_refs)]
unsafe extern "system" fn wnd_proc(hwnd: HWND, msg: u32, wp: WPARAM, lp: LPARAM) -> LRESULT {
    match msg {
        WM_CREATE => {
            let list = CreateWindowExW(
                0, wide("LISTBOX").as_ptr(), ptr::null(),
                WS_CHILD | WS_VISIBLE | WS_BORDER | WS_VSCROLL | LBS_NOTIFY as u32,
                10, 10, 480, 300, hwnd, ID_LIST as HMENU, 0, ptr::null(),
            );
            macro_rules! btn {
                ($id:expr, $lbl:literal, $x:expr, $y:expr, $w:expr) => {
                    CreateWindowExW(
                        0, wide("BUTTON").as_ptr(), wide($lbl).as_ptr(),
                        WS_CHILD | WS_VISIBLE | BS_PUSHBUTTON as u32,
                        $x, $y, $w, 28, hwnd, $id as HMENU, 0, ptr::null(),
                    )
                };
            }
            btn!(ID_ADD_FILE,   "Add file...",          10,  320, 150);
            btn!(ID_ADD_FOLDER, "Add folder...",         170, 320, 150);
            btn!(ID_REMOVE,     "Remove entry",          330, 320, 160);
            btn!(ID_LAUNCH,     "Launch + Watch",        10,  360, 480);
            let status = CreateWindowExW(
                0, wide("STATIC").as_ptr(), wide("Ready.").as_ptr(),
                WS_CHILD | WS_VISIBLE,
                10, 400, 480, 50, hwnd, ID_STATUS as HMENU, 0, ptr::null(),
            );
            macro_rules! lbl {
                ($txt:expr, $x:expr, $y:expr) => {
                    CreateWindowExW(0, wide("STATIC").as_ptr(), wide($txt).as_ptr(),
                        WS_CHILD | WS_VISIBLE, $x, $y, 130, 18,
                        hwnd, 0, 0, ptr::null())
                }
            }
            macro_rules! edt {
                ($val:expr, $x:expr, $y:expr, $id:expr) => {
                    CreateWindowExW(WS_EX_CLIENTEDGE,
                        wide("EDIT").as_ptr(), wide($val).as_ptr(),
                        WS_CHILD | WS_VISIBLE | ES_AUTOHSCROLL as u32,
                        $x, $y, 80, 20, hwnd, $id as HMENU, 0, ptr::null())
                }
            }
            lbl!("Affinity (hex):",    10,  462);
            lbl!("Poll (secs):",       270, 462);
            lbl!("RAM limit (MiB):",   10,  486);
            lbl!("Hang limit (secs):", 270, 486);
            let hw_mask = edt!(&format!("{:#x}", CPU_AFFINITY_MASK), 148, 460, ID_SET_MASK);
            let hw_ivl  = edt!(&WATCHDOG_INTERVAL_SECS.to_string(),  400, 460, ID_SET_IVL);
            let hw_ram  = edt!(&RAM_LIMIT_MIB.to_string(),           148, 484, ID_SET_RAM);
            let hw_hang = edt!(&HANG_LIMIT_SECS.to_string(),         400, 484, ID_SET_HANG);

            UI = Some(Ui {
                entries: load_entries(),
                list, status,
                hw_mask, hw_ivl, hw_ram, hw_hang,
            });
            if let Some(ui) = UI.as_ref() {
                rebuild_list(ui.list, &ui.entries);
            }
            0
        }

        WM_COMMAND => {
            let id = (wp & 0xFFFF) as usize;
            match id {

                ID_ADD_FILE => {
                    if let Some(path) = pick_file(hwnd) {
                        if let Some(ui) = UI.as_mut() {
                            let label = path.file_name().unwrap_or_default()
                                        .to_string_lossy().into_owned();
                            let ps = path.display().to_string();
                            if ui.entries.iter().any(|e| e.path == ps) {
                                set_status(ui.status, "Already in list.");
                            } else {
                                ui.entries.push(Entry { path: ps, label });
                                save_entries(&ui.entries);
                                rebuild_list(ui.list, &ui.entries);
                                set_status(ui.status, "Entry added.");
                            }
                        }
                    }
                    0
                }

                ID_ADD_FOLDER => {
                    if let Some(folder) = pick_folder(hwnd) {
                        let apps = scan_folder(&folder);
                        if apps.is_empty() {
                            msgbox(hwnd, "No apps found",
                                "No .exe / .bat / .cmd files found in that folder.",
                                MB_OK | MB_ICONINFORMATION);
                        } else {
                            let preview = apps.iter()
                                .map(|p| format!("  * {}", p.file_name()
                                    .unwrap_or_default().to_string_lossy()))
                                .collect::<Vec<_>>().join("\n");
                            let q = format!("Found {} app(s):\n\n{}\n\nAdd all?",
                                apps.len(), preview);
                            if msgbox(hwnd, "Add from folder", &q,
                                MB_YESNO | MB_ICONQUESTION) == IDYES as i32
                            {
                                if let Some(ui) = UI.as_mut() {
                                    let mut added = 0usize;
                                    for p in &apps {
                                        let ps = p.display().to_string();
                                        if !ui.entries.iter().any(|e| e.path == ps) {
                                            let label = p.file_name()
                                                .unwrap_or_default()
                                                .to_string_lossy().into_owned();
                                            ui.entries.push(Entry { path: ps, label });
                                            added += 1;
                                        }
                                    }
                                    save_entries(&ui.entries);
                                    rebuild_list(ui.list, &ui.entries);
                                    set_status(ui.status,
                                        &format!("Added {} entry/entries.", added));
                                }
                            }
                        }
                    }
                    0
                }

                ID_REMOVE => {
                    if let Some(ui) = UI.as_mut() {
                        let sel = SendMessageW(ui.list, LB_GETCURSEL, 0, 0);
                        if sel >= 0 {
                            let removed = ui.entries[sel as usize].label.clone();
                            ui.entries.remove(sel as usize);
                            save_entries(&ui.entries);
                            rebuild_list(ui.list, &ui.entries);
                            set_status(ui.status, &format!(
                                "Removed '{}' from list. The file was NOT deleted.", removed));
                        } else {
                            set_status(ui.status, "Select an entry first.");
                        }
                    }
                    0
                }

                ID_LAUNCH => {
                    let ui = match UI.as_ref() { Some(u) => u, None => return 0 };
                    let sel = SendMessageW(ui.list, LB_GETCURSEL, 0, 0);
                    if sel < 0 {
                        set_status(ui.status, "Select an app to launch first.");
                        return 0;
                    }
                    let entry    = ui.entries[sel as usize].clone();
                    let status_h = ui.status;

                    let path = PathBuf::from(&entry.path);
                    if !path.exists() {
                        msgbox(hwnd, "File not found",
                            &format!("Cannot find:\n{}\n\nRemove this entry and re-add it.",
                                entry.path),
                            MB_OK | MB_ICONERROR);
                        return 0;
                    }

                    let (mask, live_ivl, live_ram, live_hang) = {
                        let ui = UI.as_ref().unwrap();
                        let m   = read_edit_hex(ui.hw_mask).unwrap_or(CPU_AFFINITY_MASK);
                        let ivl = read_edit_u64(ui.hw_ivl).unwrap_or(WATCHDOG_INTERVAL_SECS).clamp(1, 3600);
                        let ram = read_edit_hex(ui.hw_ram).unwrap_or(RAM_LIMIT_MIB);
                        let hng = read_edit_u64(ui.hw_hang).unwrap_or(HANG_LIMIT_SECS);
                        (safe_mask(m), ivl, ram, hng)
                    };
                    set_status(status_h,
                        &format!("Launching '{}' (affinity mask {:#x})...", entry.label, mask));

                    match launch_app(&path, mask) {
                        Err(e) => { msgbox(hwnd, "Launch failed", &e, MB_OK | MB_ICONERROR); }
                        Ok(launched) => {
                            let pid        = launched.pid;
                            let is_script = launched.is_script;
                            let label     = entry.label.clone();
                            let epath     = entry.path.clone();
                            CloseHandle(launched.handle);

                            set_status(status_h, &format!(
                                "Watching PID {} ('{}')  poll={}s  RAM={}MiB  hang={}s",
                                pid, label, live_ivl, live_ram, live_hang));

                            let stop     = Arc::new(AtomicBool::new(false));
                            let stop2    = Arc::clone(&stop);
                            let interval = Duration::from_secs(live_ivl);
                            let main_hwnd = hwnd;

                            thread::spawn(move || {
                                let vs = watchdog(
                                    pid, epath, is_script,
                                    live_ram, live_hang,
                                    interval, stop2);

                                let report = if vs.is_empty() {
                                    format!("'{}' (PID {}) exited normally.", label, pid)
                                } else {
                                    let mut s = format!(
                                        "'{}' (PID {}) was force-killed:\n\n", label, pid);
                                    for v in &vs {
                                        s.push_str(&format!(
                                            "  PID {}  {}\n  Path: {}\n\n",
                                            v.pid, v.reason, v.path));
                                    }
                                    s
                                };
                                let boxed = Box::into_raw(Box::new(report));
                                PostMessageW(main_hwnd, WM_DONE, 0, boxed as LPARAM);
                            });
                        }
                    }
                    0
                }

                _ => DefWindowProcW(hwnd, msg, wp, lp),
            }
        }

        x if x == WM_DONE => {
            let report = *Box::from_raw(lp as *mut String);
            if let Some(ui) = UI.as_ref() {
                let first = report.lines().next().unwrap_or("Done.").to_owned();
                set_status(ui.status, &first);
            }
            msgbox(hwnd, "Watchdog Report", &report, MB_OK | MB_ICONINFORMATION);
            0
        }

        WM_DESTROY => {
            unsafe {
                SetPriorityClass(GetCurrentProcess(), NORMAL_PRIORITY_CLASS);
            }
            PostQuitMessage(0);
            0
        }
        _ => DefWindowProcW(hwnd, msg, wp, lp),
    }
}

// ── entry point ───────────────────────────────────────────────────────────────

fn main() {
    if !is_elevated() {
        if elevate_self() {
            return;
        }
        let (code, msg_s) = last_err();
        let text = format!(
            "Administrator rights required.\n\n\
             Auto-elevation failed.\n\n\
             Error code : {:#010x}\n\
             Description: {}\n\n\
             Fix: right-click the .exe > Run as administrator.",
            code, msg_s
        );
        unsafe {
            MessageBoxW(
                0, wide(&text).as_ptr(),
                wide("Launcher - Elevation Required").as_ptr(),
                MB_OK | MB_ICONERROR,
            );
        }
        std::process::exit(code as i32);
    }

    let mask = safe_mask(CPU_AFFINITY_MASK);
    if mask != CPU_AFFINITY_MASK {
        unsafe {
            MessageBoxW(
                0,
                wide(&format!(
                    "CPU_AFFINITY_MASK {:#x} exceeds this machine's core count.\n\
                     Using {:#x} (all threads except Thread 0).\n\n\
                     Edit the constant at the top of main.rs and rebuild.",
                    CPU_AFFINITY_MASK, mask
                )).as_ptr(),
                wide("Launcher - Affinity Clamped").as_ptr(),
                MB_OK | MB_ICONWARNING,
            );
        }
    }

    let class = wide("AppLauncherClass");
    let title = wide(&format!(
        "App Launcher & Watchdog  [mask={:#x}  RAM={}MiB  hang={}s  poll={}s]",
        mask, RAM_LIMIT_MIB, HANG_LIMIT_SECS, WATCHDOG_INTERVAL_SECS
    ));

    unsafe {
        let hinstance = GetModuleHandleW(ptr::null());
        let wc = WNDCLASSEXW {
            cbSize:        mem::size_of::<WNDCLASSEXW>() as u32,
            style:         CS_HREDRAW | CS_VREDRAW,
            lpfnWndProc:   Some(wnd_proc),
            cbClsExtra:    0,
            cbWndExtra:    0,
            hInstance:     hinstance,
            hIcon:         0,
            hCursor:       LoadCursorW(0, IDC_ARROW),
            hbrBackground: (COLOR_BTNFACE + 1) as HBRUSH,
            lpszMenuName:  ptr::null(),
            lpszClassName: class.as_ptr(),
            hIconSm:       0,
        };
        if RegisterClassExW(&wc) == 0 {
            let (code, m) = last_err();
            MessageBoxW(0,
                wide(&format!("RegisterClassEx failed ({:#010x}): {}", code, m)).as_ptr(),
                wide("Fatal").as_ptr(), MB_OK | MB_ICONERROR);
            std::process::exit(code as i32);
        }

        let hwnd = CreateWindowExW(
            0, class.as_ptr(), title.as_ptr(),
            WS_OVERLAPPED | WS_CAPTION | WS_SYSMENU | WS_MINIMIZEBOX,
            CW_USEDEFAULT, CW_USEDEFAULT, 514, 520,
            0, 0, hinstance, ptr::null(),
        );
        if hwnd == 0 {
            let (code, m) = last_err();
            MessageBoxW(0,
                wide(&format!("CreateWindow failed ({:#010x}): {}", code, m)).as_ptr(),
                wide("Fatal").as_ptr(), MB_OK | MB_ICONERROR);
            std::process::exit(code as i32);
        }

        ShowWindow(hwnd, SW_SHOWNORMAL);
        UpdateWindow(hwnd);

        let mut m: MSG = mem::zeroed();
        while GetMessageW(&mut m, 0, 0, 0) > 0 {
            TranslateMessage(&m);
            DispatchMessageW(&m);
        }
    }
}