# Build Instructions

## One-time setup

1. Install Rust:   https://rustup.rs  (accept all defaults)
2. Open a new terminal (so PATH includes cargo/rustc)

## Build

```
cd path\to\launcher
cargo build --release
```

Output:  target\release\launcher.exe

## GNU toolchain (if you don't have Visual Studio)

```
rustup target add x86_64-pc-windows-gnu
cargo build --release --target x86_64-pc-windows-gnu
```
Output:  target\x86_64-pc-windows-gnu\release\launcher.exe

Note: GNU builds do not embed the UAC manifest automatically.
Right-click the exe → Properties → Compatibility → "Run as administrator",
OR use: mt.exe -manifest launcher.manifest -outputresource:launcher.exe;1

## Tuning (edit src/main.rs before building)

  CPU_AFFINITY_MASK       hex mask, skip bit 0 to reserve Core 0 for Windows
  WATCHDOG_INTERVAL_SECS  poll frequency (1–3600)
  RAM_LIMIT_MIB           kill threshold in MiB, 0 = disabled
  HANG_LIMIT_SECS         hung window kill timeout, 0 = disabled

All values are validated and clamped at startup — you cannot crash the
launcher by entering a bad value.
