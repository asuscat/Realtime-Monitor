fn main() {
    // Only apply to MSVC linker
    if std::env::var("CARGO_CFG_TARGET_ENV").as_deref() == Ok("msvc") {
        // Embed the admin requirement directly without a separate XML file
        println!("cargo:rustc-link-arg=/MANIFESTUAC:level='requireAdministrator' uiAccess='false'");
    }
    println!("cargo:rerun-if-changed=src/main.rs");
}
